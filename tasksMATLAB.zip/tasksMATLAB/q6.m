function [p, c] = perm_comb(n, r)
p=factorial(n)/factorial(n-r);
c=factorial(n)/(factorial(r)*factorial(n-r));
end

