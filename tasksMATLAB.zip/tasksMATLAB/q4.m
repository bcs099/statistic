dice=randi([1 6],1,10);
disp('dice results')
disp(dice)
coin=randi([0 1],1,10);
disp('coin toss results')
disp(coin)